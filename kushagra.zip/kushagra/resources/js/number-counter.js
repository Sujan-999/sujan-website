// //Animate my counter from 0 to set number (6)
// $({counter: 0}).animate({counter: 0}, {
//     //Animate over a period of 2seconds
//     duration: 3e3,
//     //Progress animation at constant pace using linear
//     easing:'swing',
//     step: function() {    
//       //Every step of the animation, update the number value
//       //Use ceil to round up to the nearest whole int
//       $('.count').text(Math.ceil(this.counter))
//     },
//     complete: function() {
//       //Could add in some extra animations, like a bounc of colour change once the count up is complete.
//     }
//   });

$('.count').each(function () {
    var $this = $(this);
    jQuery({ Counter: 0 }).animate({ Counter: $this.text() }, {
      duration: 3e3,
      easing: 'swing',
      step: function () {
        $this.text(Math.ceil(this.Counter));
      }
    });
  });